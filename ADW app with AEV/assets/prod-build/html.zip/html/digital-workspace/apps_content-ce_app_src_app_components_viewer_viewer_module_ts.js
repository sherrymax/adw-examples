"use strict";
(self["webpackChunkcontent_ee"] = self["webpackChunkcontent_ee"] || []).push([["apps_content-ce_app_src_app_components_viewer_viewer_module_ts"],{

/***/ 32457:
/*!***************************************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/viewer-aev/alfresco-enterprise-viewer.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlfrescoEnterpriseViewerComponent": () => (/* binding */ AlfrescoEnterpriseViewerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 18259);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 27532);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/button */ 99110);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/icon */ 18488);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 13828);














function AlfrescoEnterpriseViewerComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "adf-toolbar", 1)(2, "adf-toolbar-title", 2)(3, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AlfrescoEnterpriseViewerComponent_ng_container_0_Template_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onBackButtonClick()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "close");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 4)(8, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "iframe", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "ADF_VIEWER.ACTIONS.CLOSE"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.node.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r0.sanitizedAevUrl, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeResourceUrl"]);
} }
class AlfrescoEnterpriseViewerComponent {
    constructor(sanitizer, appConfigService, route, 
    // private router: Router,
    location, nodeService) {
        this.sanitizer = sanitizer;
        this.appConfigService = appConfigService;
        this.route = route;
        this.location = location;
        this.nodeService = nodeService;
        /* Alfresco Enterprise Viewer Code Below */
        this.AEV_APP_CONFIG_KEY = 'alfresco-enterprise-viewer';
        // ================ CUSTOM CODE ================
        this.showViewer = true;
        this.showViewerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    }
    ngOnInit() {
        this.aevConfig = this.appConfigService.config[this.AEV_APP_CONFIG_KEY];
        this.route.params.subscribe((params) => {
            this.folderId = params.folderId;
            const { nodeId } = params;
            if (nodeId) {
                console.log("Node ID = " + nodeId);
                this.nodeService.getNode(nodeId).subscribe((node) => {
                    setTimeout(() => {
                        this.node = node;
                        console.log("Node Name=" + this.node.name);
                        console.log("Node Mime Type=" + this.node.content.mimeType);
                        this.setViewerUrl();
                    }, 1000);
                });
            }
        });
    }
    setViewerUrl() {
        console.log(">>>> START OF setViewerUrl() <<<<<");
        let supportedDocTypes = this.aevConfig.properties.supportedMimetypes.documents;
        let supportedVideoTypes = this.aevConfig.properties.supportedMimetypes.videos;
        if (supportedVideoTypes.indexOf(this.node.content.mimeType) !== -1) {
            this.sanitizedAevUrl = this.getAEVUrlForVideo();
        }
        else if (supportedDocTypes.indexOf('*') !== -1 || supportedDocTypes.indexOf(this.node.content.mimeType) !== -1) {
            this.sanitizedAevUrl = this.getAEVUrl();
        }
        else {
            console.log("Cannot find a matched MIME TYPE >>>");
        }
        console.log("this.sanitizedAevUrl = " + this.sanitizedAevUrl);
    }
    /**
     *
     */
    getAEVUrl() {
        console.log("*** START OF getAEVUrl() ***");
        // update the src of the iframe to AEV's external authorization passing
        // the user login, ticket, and the id of the selected document
        //console.log("this.aevConfig.properties.endpoints.aev >> "+this.aevConfig.properties.endpoints.aev);
        let aevDocumentUrl = this.aevConfig.properties.endpoints.aev + // assuming AEV is on same server as ADF
            '/login/external.htm?' +
            'docId=' +
            this.aevConfig.properties.alfrescoDocumentStorePrefix +
            this.node.id +
            '&username=' +
            localStorage.getItem('ACS_USERNAME') +
            '&ticket=' +
            localStorage.getItem('ticket-ECM');
        console.log(aevDocumentUrl);
        console.log(this.sanitizer.bypassSecurityTrustResourceUrl(aevDocumentUrl));
        return this.sanitizer.bypassSecurityTrustResourceUrl(aevDocumentUrl);
    }
    /**
     *
     */
    getAEVUrlForVideo() {
        console.log("*** START OF getAEVUrlForVideo() ***");
        // update the src of the iframe to AEV's external authorization passing
        // the user login, ticket, and the id of the selected document
        let aevDocumentUrl = this.aevConfig.properties.endpoints.aevVideo + // assuming AEV is on same server as ADF
            '/#/login?' +
            'docName=' +
            encodeURIComponent(this.node.name) +
            '&docId=' +
            this.aevConfig.properties.alfrescoDocumentStorePrefix +
            this.node.id +
            '&username=' +
            localStorage.getItem('ACS_USERNAME');
        // for auth we need to set the cookie before we return
        document.cookie =
            'ticket' + '=' + localStorage.getItem('ticket-ECM') + ';' + 'path=/';
        return this.sanitizer.bypassSecurityTrustResourceUrl(aevDocumentUrl);
    }
    onBackButtonClick() {
        console.log('>>> CLOSE BUTTON CLICKED..');
        this.close();
    }
    close() {
        this.showViewer = false;
        this.showViewerChange.emit(this.showViewer);
        console.log('CLOSE BUTTON CLICKED..');
        this.location.back();
        //this.router.navigate(['/favorite/libraries/', this.node.parentId]);
    }
}
AlfrescoEnterpriseViewerComponent.ɵfac = function AlfrescoEnterpriseViewerComponent_Factory(t) { return new (t || AlfrescoEnterpriseViewerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.DomSanitizer), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_2__.AppConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_2__.NodesApiService)); };
AlfrescoEnterpriseViewerComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AlfrescoEnterpriseViewerComponent, selectors: [["alfresco-enterprise-viewer"]], inputs: { nodeId: "nodeId", showViewer: "showViewer" }, outputs: { showViewerChange: "showViewerChange" }, decls: 1, vars: 1, consts: [[4, "ngIf"], ["id", "adf-viewer-toolbar", 1, "adf-viewer-toolbar"], [2, "width", "auto !important"], ["data-automation-id", "adf-toolbar-back", "mat-icon-button", "", 1, "adf-viewer-close-button", 3, "title", "click"], ["fxFlex", "1 1 auto", 1, "adf-viewer__file-title", 2, "flex", "1 1 auto", "box-sizing", "border-box"], ["id", "adf-viewer-display-name", 1, "adf-viewer__display-name"], [1, "alfresco-enterprise-viewer", 3, "src"]], template: function AlfrescoEnterpriseViewerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AlfrescoEnterpriseViewerComponent_ng_container_0_Template, 11, 5, "ng-container", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showViewer && ctx.node);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_material_button__WEBPACK_IMPORTED_MODULE_5__.MatButton, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIcon, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_2__.ToolbarComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_2__.ToolbarTitleComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe], styles: ["iframe.alfresco-enterprise-viewer {\n  width: 100%;\n  height: 100%;\n  border: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFsZnJlc2NvLWVudGVycHJpc2Utdmlld2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQ0oiLCJmaWxlIjoiYWxmcmVzY28tZW50ZXJwcmlzZS12aWV3ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpZnJhbWUuYWxmcmVzY28tZW50ZXJwcmlzZS12aWV3ZXIge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBib3JkZXI6IG5vbmU7XG59Il19 */"], encapsulation: 2 });


/***/ }),

/***/ 8523:
/*!***************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/viewer/viewer.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppViewerComponent": () => (/* binding */ AppViewerComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @alfresco/aca-shared */ 27125);
/* harmony import */ var _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @alfresco/aca-shared/store */ 99311);
/* harmony import */ var _alfresco_js_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @alfresco/js-api */ 92501);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 18259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 79441);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 34361);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 22663);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 80639);
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngrx/effects */ 47716);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngrx/store */ 9876);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _projects_aca_shared_src_lib_components_info_drawer_info_drawer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/info-drawer/info-drawer.component */ 11204);
/* harmony import */ var _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/tool-bar/toolbar-action/toolbar-action.component */ 82121);
/* harmony import */ var _projects_aca_shared_src_lib_components_tool_bar_toolbar_menu_item_toolbar_menu_item_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/tool-bar/toolbar-menu-item/toolbar-menu-item.component */ 21837);
/* harmony import */ var _viewer_aev_alfresco_enterprise_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../viewer-aev/alfresco-enterprise-viewer.component */ 32457);

/*!
 * @license
 * Alfresco Example Content Application
 *
 * Copyright (C) 2005 - 2020 Alfresco Software Limited
 *
 * This file is part of the Alfresco Example Content Application.
 * If the software was purchased under a paid Alfresco license, the terms of
 * the paid license agreement will prevail.  Otherwise, the software is
 * provided under the following open source license terms:
 *
 * The Alfresco Example Content Application is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Alfresco Example Content Application is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */





















function AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_sidebar_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "adf-viewer-sidebar");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "aca-info-drawer", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("node", ctx_r3.selection.file);
} }
function AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_open_with_4_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "app-toolbar-menu-item", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("actionRef", action_r7);
} }
function AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_open_with_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "adf-viewer-open-with");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_open_with_4_ng_container_1_Template, 2, 1, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r4.openWith)("ngForTrackBy", ctx_r4.trackByActionId);
} }
function AppViewerComponent_ng_container_0_adf_viewer_1_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "aca-toolbar-action", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("actionRef", action_r8);
} }
const _c0 = function (a0) { return { "right_side--hide": a0 }; };
function AppViewerComponent_ng_container_0_adf_viewer_1_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "adf-viewer", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("showViewerChange", function AppViewerComponent_ng_container_0_adf_viewer_1_Template_adf_viewer_showViewerChange_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r9.onViewerVisibilityChanged()); })("navigateBefore", function AppViewerComponent_ng_container_0_adf_viewer_1_Template_adf_viewer_navigateBefore_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.onNavigateBefore($event)); })("navigateNext", function AppViewerComponent_ng_container_0_adf_viewer_1_Template_adf_viewer_navigateNext_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r12.onNavigateNext($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](1, "adfAppConfig");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_sidebar_2_Template, 2, 1, "adf-viewer-sidebar", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, AppViewerComponent_ng_container_0_adf_viewer_1_adf_viewer_open_with_4_Template, 2, 2, "adf-viewer-open-with", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "adf-viewer-toolbar-actions");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, AppViewerComponent_ng_container_0_adf_viewer_1_ng_container_6_Template, 2, 1, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](22, _c0, !ctx_r1.showRightSide))("fileName", ctx_r1.fileName)("maxRetries", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](1, 18, "viewer.maxRetries"))("nodeId", ctx_r1.nodeId)("versionId", ctx_r1.versionId)("allowNavigate", ctx_r1.navigateMultiple)("allowRightSidebar", true)("allowPrint", false)("showRightSidebar", true)("allowDownload", false)("allowFullScreen", false)("overlayMode", true)("canNavigateBefore", !!ctx_r1.previousNodeId)("canNavigateNext", !!ctx_r1.nextNodeId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](3, 20, ctx_r1.infoDrawerOpened$));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r1.openWith.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r1.toolbarActions)("ngForTrackBy", ctx_r1.trackByActionId);
} }
function AppViewerComponent_ng_container_0_alfresco_enterprise_viewer_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "alfresco-enterprise-viewer", 7);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("nodeId", ctx_r2.nodeId);
} }
function AppViewerComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, AppViewerComponent_ng_container_0_adf_viewer_1_Template, 7, 24, "adf-viewer", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, AppViewerComponent_ng_container_0_alfresco_enterprise_viewer_2_Template, 1, 1, "alfresco-enterprise-viewer", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx_r0.showAEV);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r0.showAEV);
} }
class AppViewerComponent {
    constructor(router, route, store, extensions, contentApi, actions$, preferences, apiService, uploadService, appHookService, storageService) {
        this.router = router;
        this.route = route;
        this.store = store;
        this.extensions = extensions;
        this.contentApi = contentApi;
        this.actions$ = actions$;
        this.preferences = preferences;
        this.apiService = apiService;
        this.uploadService = uploadService;
        this.appHookService = appHookService;
        this.storageService = storageService;
        this.showViewer = true;
        this.showViewerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
        this.onDestroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
        this.folderId = null;
        this.versionId = null;
        this.showRightSide = false;
        this.showAEV = false;
        this.openWith = [];
        this.toolbarActions = [];
        this.navigateSource = null;
        this.navigateMultiple = true;
        this.routesSkipNavigation = ['shared', 'recent-files', 'favorites'];
        this.navigationSources = ['favorites', 'libraries', 'personal-files', 'recent-files', 'shared'];
        this.recentFileFilters = [
            'TYPE:"content"',
            '-PNAME:"0/wiki"',
            '-TYPE:"app:filelink"',
            '-TYPE:"fm:post"',
            '-TYPE:"cm:thumbnail"',
            '-TYPE:"cm:failedThumbnail"',
            '-TYPE:"cm:rating"',
            '-TYPE:"dl:dataList"',
            '-TYPE:"dl:todoList"',
            '-TYPE:"dl:issue"',
            '-TYPE:"dl:contact"',
            '-TYPE:"dl:eventAgenda"',
            '-TYPE:"dl:event"',
            '-TYPE:"dl:task"',
            '-TYPE:"dl:simpletask"',
            '-TYPE:"dl:meetingAgenda"',
            '-TYPE:"dl:location"',
            '-TYPE:"fm:topic"',
            '-TYPE:"fm:post"',
            '-TYPE:"ia:calendarEvent"',
            '-TYPE:"lnk:link"'
        ];
        this.containersSkipNavigation = ['adf-viewer__sidebar', 'cdk-overlay-container', 'adf-image-viewer'];
    }
    get versionsApi() {
        var _a;
        this._versionsApi = (_a = this._versionsApi) !== null && _a !== void 0 ? _a : new _alfresco_js_api__WEBPACK_IMPORTED_MODULE_8__.VersionsApi(this.apiService.getInstance());
        return this._versionsApi;
    }
    ngOnInit() {
        this.infoDrawerOpened$ = this.store.select(_alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.isInfoDrawerOpened);
        console.log(this.storageService.getItem("viewerType"));
        this.showAEV = (this.storageService.getItem("viewerType") == "AEV");
        console.log(this.showAEV);
        (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.from)(this.infoDrawerOpened$)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$))
            .subscribe((val) => {
            this.showRightSide = val;
        });
        this.store
            .select(_alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.getAppSelection)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$))
            .subscribe((selection) => {
            this.selection = selection;
        });
        this.extensions
            .getViewerToolbarActions()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$))
            .subscribe((actions) => {
            this.toolbarActions = actions;
        });
        this.extensions
            .getOpenWithActions()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$))
            .subscribe((actions) => {
            this.openWith = actions;
        });
        this.route.params.subscribe((params) => {
            this.folderId = params.folderId;
            const { nodeId } = params;
            this.versionId = params.versionId;
            if (this.versionId) {
                this.versionsApi.getVersion(nodeId, this.versionId).then((version) => {
                    if (version) {
                        this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.SetCurrentNodeVersionAction(version));
                    }
                });
            }
            if (nodeId) {
                this.displayNode(nodeId);
            }
        });
        this.route.queryParams.subscribe((params) => {
            this.navigationPath = params.path || params.location;
        });
        if (this.route.snapshot.data && this.route.snapshot.data.navigateSource) {
            const source = this.route.snapshot.data.navigateSource.toLowerCase();
            if (this.navigationSources.includes(source)) {
                this.navigateSource = this.route.snapshot.data.navigateSource;
            }
        }
        this.actions$.pipe((0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_11__.ofType)(_alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.ViewerActionTypes.ClosePreview), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$)).subscribe(() => {
            this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.SetCurrentNodeVersionAction(null));
            this.navigateToFileLocation();
        });
        this.actions$
            .pipe((0,_ngrx_effects__WEBPACK_IMPORTED_MODULE_11__.ofType)(_alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.ViewerActionTypes.RefreshPreview), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$))
            .subscribe((action) => {
            var _a, _b;
            this.displayNode((_b = (_a = action === null || action === void 0 ? void 0 : action.payload) === null || _a === void 0 ? void 0 : _a.entry) === null || _b === void 0 ? void 0 : _b.id);
        });
        this.appHookService.nodesDeleted.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$)).subscribe(() => this.navigateToFileLocation());
        this.uploadService.fileUploadDeleted.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$)).subscribe(() => this.navigateToFileLocation());
        this.uploadService.fileUploadComplete.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.debounceTime)(300), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.onDestroy$)).subscribe((file) => {
            this.apiService.nodeUpdated.next(file.data.entry);
            this.displayNode(file.data.entry.id);
        });
        this.previewLocation = this.router.url.substr(0, this.router.url.indexOf('/', 1)).replace(/\//g, '');
    }
    onViewerVisibilityChanged() {
        this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.ReloadDocumentListAction());
        this.navigateToFileLocation();
    }
    ngOnDestroy() {
        this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.SetCurrentNodeVersionAction(null));
        this.onDestroy$.next(true);
        this.onDestroy$.complete();
    }
    trackByActionId(_, obj) {
        return obj.id;
    }
    displayNode(nodeId) {
        var _a, _b, _c, _d;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            if (nodeId) {
                try {
                    this.node = yield this.contentApi.getNodeInfo(nodeId).toPromise();
                    this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.SetSelectedNodesAction([{ entry: this.node }]));
                    this.navigateMultiple = this.extensions.canShowViewerNavigation({ entry: this.node });
                    if (!this.navigateMultiple) {
                        this.nodeId = this.node.id;
                        this.fileName = this.node.name + ((_b = (_a = this.node) === null || _a === void 0 ? void 0 : _a.properties) === null || _b === void 0 ? void 0 : _b['cm:versionLabel']);
                        return;
                    }
                    if (this.node && this.node.isFile) {
                        const nearest = yield this.getNearestNodes(this.node.id, this.node.parentId);
                        this.nodeId = this.node.id;
                        this.previousNodeId = nearest.left;
                        this.nextNodeId = nearest.right;
                        this.fileName = this.node.name + ((_d = (_c = this.node) === null || _c === void 0 ? void 0 : _c.properties) === null || _d === void 0 ? void 0 : _d['cm:versionLabel']);
                        return;
                    }
                }
                catch (error) {
                    const statusCode = JSON.parse(error.message).error.statusCode;
                    if (statusCode !== 401) {
                        this.router.navigate([this.previewLocation, { outlets: { viewer: null } }]).then(() => {
                            this.router.navigate([this.previewLocation, nodeId]);
                        });
                    }
                }
            }
        });
    }
    onNavigateBefore(event) {
        if (event.type !== 'click' && this.shouldNavigate(event.target)) {
            return;
        }
        const location = this.getFileLocation();
        this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.ViewNodeAction(this.previousNodeId, { location }));
    }
    onNavigateNext(event) {
        if (event.type !== 'click' && this.shouldNavigate(event.target)) {
            return;
        }
        const location = this.getFileLocation();
        this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_1__.ViewNodeAction(this.nextNodeId, { location }));
    }
    /**
     * Retrieves nearest node information for the given node and folder.
     *
     * @param nodeId Unique identifier of the document node
     * @param folderId Unique identifier of the containing folder node.
     */
    getNearestNodes(nodeId, folderId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const empty = {
                left: null,
                right: null
            };
            if (nodeId && folderId) {
                try {
                    const ids = yield this.getFileIds(this.navigateSource, folderId);
                    const idx = ids.indexOf(nodeId);
                    if (idx >= 0) {
                        return {
                            left: ids[idx - 1] || null,
                            right: ids[idx + 1] || null
                        };
                    }
                    else {
                        return empty;
                    }
                }
                catch (_a) {
                    return empty;
                }
            }
            else {
                return empty;
            }
        });
    }
    /**
     * Retrieves a list of node identifiers for the folder and data source.
     *
     * @param source Data source name. Allowed values are: personal-files, libraries, favorites, shared, recent-files.
     * @param folderId Containing folder node identifier for 'personal-files' and 'libraries' sources.
     */
    getFileIds(source, folderId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            if ((source === 'personal-files' || source === 'libraries') && folderId) {
                const sortKey = this.preferences.get('personal-files.sorting.key') || 'modifiedAt';
                const sortDirection = this.preferences.get('personal-files.sorting.direction') || 'desc';
                const nodes = yield this.contentApi
                    .getNodeChildren(folderId, {
                    // orderBy: `${sortKey} ${sortDirection}`,
                    fields: ['id', this.getRootField(sortKey)],
                    where: '(isFile=true)'
                })
                    .toPromise();
                const entries = nodes.list.entries.map((obj) => obj.entry);
                this.sort(entries, sortKey, sortDirection);
                return entries.map((obj) => obj.id);
            }
            if (source === 'favorites') {
                const nodes = yield this.contentApi
                    .getFavorites('-me-', {
                    where: '(EXISTS(target/file))',
                    fields: ['target']
                })
                    .toPromise();
                const sortKey = this.preferences.get('favorites.sorting.key') || 'modifiedAt';
                const sortDirection = this.preferences.get('favorites.sorting.direction') || 'desc';
                const files = nodes.list.entries.map((obj) => obj.entry.target.file);
                this.sort(files, sortKey, sortDirection);
                return files.map((f) => f.id);
            }
            if (source === 'shared') {
                const sortingKey = this.preferences.get('shared.sorting.key') || 'modifiedAt';
                const sortingDirection = this.preferences.get('shared.sorting.direction') || 'desc';
                const nodes = yield this.contentApi
                    .findSharedLinks({
                    fields: ['nodeId', this.getRootField(sortingKey)]
                })
                    .toPromise();
                const entries = nodes.list.entries.map((obj) => obj.entry);
                this.sort(entries, sortingKey, sortingDirection);
                return entries.map((obj) => obj.nodeId);
            }
            if (source === 'recent-files') {
                const person = yield this.contentApi.getPerson('-me-').toPromise();
                const username = person.entry.id;
                const sortingKey = this.preferences.get('recent-files.sorting.key') || 'modifiedAt';
                const sortingDirection = this.preferences.get('recent-files.sorting.direction') || 'desc';
                const query = {
                    query: {
                        query: '*',
                        language: 'afts'
                    },
                    filterQueries: [
                        { query: `cm:modified:[NOW/DAY-30DAYS TO NOW/DAY+1DAY]` },
                        { query: `cm:modifier:${username} OR cm:creator:${username}` },
                        {
                            query: this.recentFileFilters.join(' AND ')
                        }
                    ],
                    fields: ['id', this.getRootField(sortingKey)],
                    include: ['path', 'properties', 'allowableOperations'],
                    sort: [
                        {
                            type: 'FIELD',
                            field: 'cm:modified',
                            ascending: false
                        }
                    ]
                };
                const nodes = yield this.contentApi.search(query).toPromise();
                const entries = nodes.list.entries.map((obj) => obj.entry);
                this.sort(entries, sortingKey, sortingDirection);
                return entries.map((obj) => obj.id);
            }
            return [];
        });
    }
    /**
     * Get the root field name from the property path.
     * Example: 'property1.some.child.property' => 'property1'
     *
     * @param path Property path
     */
    getRootField(path) {
        if (path) {
            return path.split('.')[0];
        }
        return path;
    }
    handleKeyboardEvent(event) {
        const key = event.keyCode;
        const rightArrow = 39;
        const leftArrow = 37;
        if (key === rightArrow || key === leftArrow) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }
    sort(items, key, direction) {
        const options = {};
        if (key.includes('sizeInBytes') || key === 'name') {
            options.numeric = true;
        }
        items.sort((a, b) => {
            let left = _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ObjectUtils.getValue(a, key);
            if (left) {
                left = left instanceof Date ? left.valueOf().toString() : left.toString();
            }
            else {
                left = '';
            }
            let right = _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ObjectUtils.getValue(b, key);
            if (right) {
                right = right instanceof Date ? right.valueOf().toString() : right.toString();
            }
            else {
                right = '';
            }
            return direction === 'asc' ? left.localeCompare(right, undefined, options) : right.localeCompare(left, undefined, options);
        });
    }
    navigateToFileLocation() {
        const location = this.getFileLocation();
        this.router.navigateByUrl(location);
    }
    getFileLocation() {
        return this.navigationPath || this.router.parseUrl(this.router.url).root.children[_angular_router__WEBPACK_IMPORTED_MODULE_15__.PRIMARY_OUTLET].toString();
    }
    shouldNavigate(element) {
        let currentElement = element.parentElement;
        while (currentElement && !this.isChild(currentElement.classList)) {
            currentElement = currentElement.parentElement;
        }
        return !!currentElement;
    }
    isChild(list) {
        return Array.from(list).some((className) => this.containersSkipNavigation.includes(className));
    }
}
AppViewerComponent.ɵfac = function AppViewerComponent_Factory(t) { return new (t || AppViewerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_16__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_0__.AppExtensionService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_0__.ContentApiService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_11__.Actions), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.UserPreferencesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.AlfrescoApiService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.UploadService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_0__.AppHookService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.StorageService)); };
AppViewerComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: AppViewerComponent, selectors: [["app-viewer"]], hostAttrs: [1, "app-viewer"], hostBindings: function AppViewerComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keydown", function AppViewerComponent_keydown_HostBindingHandler($event) { return ctx.handleKeyboardEvent($event); }, false, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresolveDocument"]);
    } }, inputs: { showViewer: "showViewer", nodeId: "nodeId" }, outputs: { showViewerChange: "showViewerChange" }, decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "ngClass", "fileName", "maxRetries", "nodeId", "versionId", "allowNavigate", "allowRightSidebar", "allowPrint", "showRightSidebar", "allowDownload", "allowFullScreen", "overlayMode", "canNavigateBefore", "canNavigateNext", "showViewerChange", "navigateBefore", "navigateNext", 4, "ngIf"], [3, "nodeId", 4, "ngIf"], [3, "ngClass", "fileName", "maxRetries", "nodeId", "versionId", "allowNavigate", "allowRightSidebar", "allowPrint", "showRightSidebar", "allowDownload", "allowFullScreen", "overlayMode", "canNavigateBefore", "canNavigateNext", "showViewerChange", "navigateBefore", "navigateNext"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "node"], [3, "actionRef"], [3, "nodeId"]], template: function AppViewerComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](0, AppViewerComponent_ng_container_0_Template, 3, 2, "ng-container", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.nodeId);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_17__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerSidebarComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerOpenWithComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerToolbarActionsComponent, _projects_aca_shared_src_lib_components_info_drawer_info_drawer_component__WEBPACK_IMPORTED_MODULE_2__.InfoDrawerComponent, _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_3__.ToolbarActionComponent, _projects_aca_shared_src_lib_components_tool_bar_toolbar_menu_item_toolbar_menu_item_component__WEBPACK_IMPORTED_MODULE_4__.ToolbarMenuItemComponent, _viewer_aev_alfresco_enterprise_viewer_component__WEBPACK_IMPORTED_MODULE_5__.AlfrescoEnterpriseViewerComponent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.AsyncPipe, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.AppConfigPipe], styles: [".app-viewer {\n  width: 100%;\n  height: 100%;\n}\n.app-viewer .adf-viewer-toolbar .adf-toolbar-divider {\n  display: none;\n}\n.app-viewer .adf-viewer-toolbar-actions {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n}\n.app-viewer .adf-viewer-toolbar-actions .adf-toolbar-divider {\n  display: inline;\n}\n.app-viewer .adf-viewer-toolbar .mat-toolbar > button:last-child {\n  display: none;\n}\n.app-viewer .adf-viewer.right_side--hide .adf-viewer__sidebar__right {\n  width: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpZXdlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFDRTtFQUNFLGFBQUE7QUFDSjtBQUVFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFBSjtBQUVJO0VBQ0UsZUFBQTtBQUFOO0FBS0U7RUFDRSxhQUFBO0FBSEo7QUFNRTtFQUNFLFFBQUE7QUFKSiIsImZpbGUiOiJ2aWV3ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYXBwLXZpZXdlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG5cbiAgLmFkZi12aWV3ZXItdG9vbGJhciAuYWRmLXRvb2xiYXItZGl2aWRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuXG4gIC5hZGYtdmlld2VyLXRvb2xiYXItYWN0aW9ucyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAuYWRmLXRvb2xiYXItZGl2aWRlciB7XG4gICAgICBkaXNwbGF5OiBpbmxpbmU7XG4gICAgfVxuICB9XG5cbiAgLy8gdG9kbzogcmVtb3ZlIHRoaXMgd2hlbiB2aWV3ZXIgc3VwcG9ydHMgZXh0ZW5zaW9uc1xuICAuYWRmLXZpZXdlci10b29sYmFyIC5tYXQtdG9vbGJhciA+IGJ1dHRvbjpsYXN0LWNoaWxkIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLmFkZi12aWV3ZXIucmlnaHRfc2lkZS0taGlkZSAuYWRmLXZpZXdlcl9fc2lkZWJhcl9fcmlnaHQge1xuICAgIHdpZHRoOiAwO1xuICB9XG59XG4iXX0= */"], encapsulation: 2 });


/***/ }),

/***/ 41445:
/*!************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/viewer/viewer.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppViewerModule": () => (/* binding */ AppViewerModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @alfresco/adf-content-services */ 2976);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../directives/directives.module */ 22595);
/* harmony import */ var _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../info-drawer/info.drawer.module */ 53617);
/* harmony import */ var _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../extensions/core.extensions.module */ 30416);
/* harmony import */ var _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolbar/toolbar.module */ 72390);
/* harmony import */ var _viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./viewer.component */ 8523);
/* harmony import */ var _viewer_aev_alfresco_enterprise_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../viewer-aev/alfresco-enterprise-viewer.component */ 32457);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 18259);














const routes = [
    {
        path: '',
        data: {
            title: 'APP.PREVIEW.TITLE',
            navigateMultiple: true
        },
        component: _viewer_component__WEBPACK_IMPORTED_MODULE_4__.AppViewerComponent
    }
];
class AppViewerModule {
}
AppViewerModule.ɵfac = function AppViewerModule_Factory(t) { return new (t || AppViewerModule)(); };
AppViewerModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: AppViewerModule });
AppViewerModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild(routes),
        _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_9__.CoreModule.forChild(),
        _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__.ContentDirectiveModule,
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_0__.DirectivesModule,
        _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_1__.AppInfoDrawerModule,
        _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_2__.CoreExtensionsModule.forChild(),
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__.AppToolbarModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](AppViewerModule, { declarations: [_viewer_component__WEBPACK_IMPORTED_MODULE_4__.AppViewerComponent, _viewer_aev_alfresco_enterprise_viewer_component__WEBPACK_IMPORTED_MODULE_5__.AlfrescoEnterpriseViewerComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_9__.CoreModule, _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__.ContentDirectiveModule,
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_0__.DirectivesModule,
        _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_1__.AppInfoDrawerModule, _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_2__.CoreExtensionsModule, _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__.AppToolbarModule], exports: [_viewer_component__WEBPACK_IMPORTED_MODULE_4__.AppViewerComponent, _viewer_aev_alfresco_enterprise_viewer_component__WEBPACK_IMPORTED_MODULE_5__.AlfrescoEnterpriseViewerComponent] }); })();


/***/ })

}]);
//# sourceMappingURL=apps_content-ce_app_src_app_components_viewer_viewer_module_ts.js.map