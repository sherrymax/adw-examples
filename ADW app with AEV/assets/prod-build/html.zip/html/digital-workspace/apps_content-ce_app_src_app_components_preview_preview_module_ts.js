"use strict";
(self["webpackChunkcontent_ee"] = self["webpackChunkcontent_ee"] || []).push([["apps_content-ce_app_src_app_components_preview_preview_module_ts"],{

/***/ 35932:
/*!**************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/preview/preview.module.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreviewModule": () => (/* binding */ PreviewModule)
/* harmony export */ });
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @alfresco/adf-content-services */ 2976);
/* harmony import */ var _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../extensions/core.extensions.module */ 30416);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../directives/directives.module */ 22595);
/* harmony import */ var _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../info-drawer/info.drawer.module */ 53617);
/* harmony import */ var _preview_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./preview.component */ 73522);
/* harmony import */ var _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolbar/toolbar.module */ 72390);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 18259);
/*!
 * @license
 * Alfresco Example Content Application
 *
 * Copyright (C) 2005 - 2020 Alfresco Software Limited
 *
 * This file is part of the Alfresco Example Content Application.
 * If the software was purchased under a paid Alfresco license, the terms of
 * the paid license agreement will prevail.  Otherwise, the software is
 * provided under the following open source license terms:
 *
 * The Alfresco Example Content Application is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Alfresco Example Content Application is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */













const routes = [
    {
        path: '',
        component: _preview_component__WEBPACK_IMPORTED_MODULE_3__.PreviewComponent,
        data: {
            title: 'APP.PREVIEW.TITLE',
            navigateMultiple: true
        }
    }
];
class PreviewModule {
}
PreviewModule.ɵfac = function PreviewModule_Factory(t) { return new (t || PreviewModule)(); };
PreviewModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: PreviewModule });
PreviewModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
        _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes),
        _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule.forChild(),
        _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_9__.ContentDirectiveModule,
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__.DirectivesModule,
        _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_2__.AppInfoDrawerModule,
        _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_0__.CoreExtensionsModule.forChild(),
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_4__.AppToolbarModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](PreviewModule, { declarations: [_preview_component__WEBPACK_IMPORTED_MODULE_3__.PreviewComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule, _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_9__.ContentDirectiveModule,
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__.DirectivesModule,
        _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_2__.AppInfoDrawerModule, _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_0__.CoreExtensionsModule, _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_4__.AppToolbarModule], exports: [_preview_component__WEBPACK_IMPORTED_MODULE_3__.PreviewComponent] }); })();


/***/ })

}]);
//# sourceMappingURL=apps_content-ce_app_src_app_components_preview_preview_module_ts.js.map