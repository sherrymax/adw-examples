"use strict";
(self["webpackChunkcontent_ee"] = self["webpackChunkcontent_ee"] || []).push([["apps_content-ce_app_src_app_components_trashcan_trashcan_module_ts"],{

/***/ 69222:
/*!*******************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/trashcan/trashcan.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TrashcanComponent": () => (/* binding */ TrashcanComponent)
/* harmony export */ });
/* harmony import */ var _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @alfresco/aca-shared/store */ 99311);
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/layout */ 50158);
/* harmony import */ var _services_content_management_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/content-management.service */ 66602);
/* harmony import */ var _page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../page.component */ 62006);
/* harmony import */ var _alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @alfresco/aca-shared */ 27125);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 18259);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngrx/store */ 9876);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @alfresco/adf-content-services */ 2976);
/* harmony import */ var _directives_document_list_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../directives/document-list.directive */ 82433);
/* harmony import */ var _projects_aca_shared_src_lib_directives_pagination_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/directives/pagination.directive */ 1079);
/* harmony import */ var _projects_aca_shared_src_lib_directives_contextmenu_contextmenu_directive__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/directives/contextmenu/contextmenu.directive */ 83723);
/* harmony import */ var _alfresco_adf_extensions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @alfresco/adf-extensions */ 46463);
/* harmony import */ var _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/tool-bar/toolbar-action/toolbar-action.component */ 82121);
/* harmony import */ var _projects_aca_shared_src_lib_components_page_layout_page_layout_content_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/page-layout/page-layout-content.component */ 71856);
/* harmony import */ var _projects_aca_shared_src_lib_components_page_layout_page_layout_header_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/page-layout/page-layout-header.component */ 15012);
/* harmony import */ var _projects_aca_shared_src_lib_components_page_layout_page_layout_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/page-layout/page-layout.component */ 57618);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 13828);
/*!
 * @license
 * Alfresco Example Content Application
 *
 * Copyright (C) 2005 - 2020 Alfresco Software Limited
 *
 * This file is part of the Alfresco Example Content Application.
 * If the software was purchased under a paid Alfresco license, the terms of
 * the paid license agreement will prevail.  Otherwise, the software is
 * provided under the following open source license terms:
 *
 * The Alfresco Example Content Application is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Alfresco Example Content Application is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */























function TrashcanComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "aca-toolbar-action", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const entry_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("actionRef", entry_r4);
} }
function TrashcanComponent_ng_container_19_ng_container_1_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "adf-dynamic-column", 13);
} if (rf & 2) {
    const context_r9 = ctx.$implicit;
    const column_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", column_r5.template)("context", context_r9);
} }
function TrashcanComponent_ng_container_19_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "data-column", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, TrashcanComponent_ng_container_19_ng_container_1_ng_template_2_Template, 1, 2, "ng-template");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const column_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵclassMap"](column_r5.class);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("key", column_r5.key)("title", column_r5.title)("type", column_r5.type)("format", column_r5.format)("sortable", column_r5.sortable);
} }
function TrashcanComponent_ng_container_19_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "data-column", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const column_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵclassMap"](column_r5.class);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("key", column_r5.key)("title", column_r5.title)("type", column_r5.type)("format", column_r5.format)("sortable", column_r5.sortable);
} }
function TrashcanComponent_ng_container_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, TrashcanComponent_ng_container_19_ng_container_1_Template, 3, 7, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, TrashcanComponent_ng_container_19_ng_container_2_Template, 2, 7, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const column_r5 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", column_r5.template && !(column_r5.desktopOnly && ctx_r2.isSmallScreen));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !column_r5.template && !(column_r5.desktopOnly && ctx_r2.isSmallScreen));
} }
function TrashcanComponent_data_column_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "data-column", 14);
} }
const _c0 = function () { return ["archivedAt", "desc"]; };
class TrashcanComponent extends _page_component__WEBPACK_IMPORTED_MODULE_2__.PageComponent {
    constructor(content, extensions, store, breakpointObserver) {
        super(store, extensions, content);
        this.breakpointObserver = breakpointObserver;
        this.isSmallScreen = false;
        this.columns = [];
        this.user$ = this.store.select(_alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_0__.getUserProfile);
    }
    ngOnInit() {
        super.ngOnInit();
        this.subscriptions.push(this.breakpointObserver.observe([_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__.Breakpoints.HandsetPortrait, _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__.Breakpoints.HandsetLandscape]).subscribe((result) => {
            this.isSmallScreen = result.matches;
        }));
        this.columns = this.extensions.documentListPresets.trashcan || [];
    }
}
TrashcanComponent.ɵfac = function TrashcanComponent_Factory(t) { return new (t || TrashcanComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_content_management_service__WEBPACK_IMPORTED_MODULE_1__.ContentManagementService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_3__.AppExtensionService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_13__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__.BreakpointObserver)); };
TrashcanComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: TrashcanComponent, selectors: [["ng-component"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"]], decls: 23, vars: 22, consts: [["root", "APP.BROWSE.TRASHCAN.TITLE"], [1, "adf-toolbar--inline"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "main-content"], ["acaDocumentList", "", "acaContextActions", "", "currentFolderId", "-trashcan-", "selectionMode", "multiple", "sortingMode", "client", 3, "display", "navigate", "imageResolver", "sorting"], ["documentList", ""], ["icon", "delete", 3, "title"], [1, "adf-empty-content__text"], ["class", "adf-ellipsis-cell", "key", "archivedByUser.displayName", "title", "APP.DOCUMENT_LIST.COLUMNS.DELETED_BY", 4, "ngIf"], ["acaPagination", "", 3, "target"], [3, "actionRef"], [4, "ngIf"], [3, "key", "title", "type", "format", "sortable"], [3, "id", "context"], ["key", "archivedByUser.displayName", "title", "APP.DOCUMENT_LIST.COLUMNS.DELETED_BY", 1, "adf-ellipsis-cell"]], template: function TrashcanComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "aca-page-layout")(1, "aca-page-layout-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "adf-breadcrumb", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "adf-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](4, TrashcanComponent_ng_container_4_Template, 2, 1, "ng-container", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "aca-page-layout-content")(6, "div", 3)(7, "adf-document-list", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](9, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "adf-custom-empty-content-template")(11, "adf-empty-content", 6)(12, "p", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "p", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](17, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](18, "data-columns");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](19, TrashcanComponent_ng_container_19_Template, 3, 2, "ng-container", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](20, TrashcanComponent_data_column_20_Template, 1, 0, "data-column", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](21, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](22, "adf-pagination", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](8);
        let tmp_11_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.actions)("ngForTrackBy", ctx.trackByActionId);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("display", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](9, 13, ctx.documentDisplayMode$))("navigate", false)("imageResolver", ctx.imageResolver)("sorting", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](21, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("title", "APP.BROWSE.TRASHCAN.EMPTY_STATE.TITLE");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 15, "APP.BROWSE.TRASHCAN.EMPTY_STATE.FIRST_TEXT"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](17, 17, "APP.BROWSE.TRASHCAN.EMPTY_STATE.SECOND_TEXT"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.columns)("ngForTrackBy", ctx.trackByColumnId);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", !ctx.isSmallScreen && ((tmp_11_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](21, 19, ctx.user$)) == null ? null : tmp_11_0.isAdmin));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("target", _r1);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.PaginationComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.ToolbarComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.DataColumnComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.DataColumnListComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.CustomEmptyContentTemplateDirective, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_15__.EmptyContentComponent, _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_16__.DocumentListComponent, _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_16__.BreadcrumbComponent, _directives_document_list_directive__WEBPACK_IMPORTED_MODULE_4__.DocumentListDirective, _projects_aca_shared_src_lib_directives_pagination_directive__WEBPACK_IMPORTED_MODULE_5__.PaginationDirective, _projects_aca_shared_src_lib_directives_contextmenu_contextmenu_directive__WEBPACK_IMPORTED_MODULE_6__.ContextActionsDirective, _alfresco_adf_extensions__WEBPACK_IMPORTED_MODULE_17__.DynamicColumnComponent, _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_7__.ToolbarActionComponent, _projects_aca_shared_src_lib_components_page_layout_page_layout_content_component__WEBPACK_IMPORTED_MODULE_8__.PageLayoutContentComponent, _projects_aca_shared_src_lib_components_page_layout_page_layout_header_component__WEBPACK_IMPORTED_MODULE_9__.PageLayoutHeaderComponent, _projects_aca_shared_src_lib_components_page_layout_page_layout_component__WEBPACK_IMPORTED_MODULE_10__.PageLayoutComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslatePipe], encapsulation: 2 });


/***/ }),

/***/ 36255:
/*!****************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/trashcan/trashcan.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppTrashcanModule": () => (/* binding */ AppTrashcanModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _trashcan_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./trashcan.component */ 69222);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @alfresco/adf-content-services */ 2976);
/* harmony import */ var _common_common_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../common/common.module */ 81054);
/* harmony import */ var _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolbar/toolbar.module */ 72390);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../directives/directives.module */ 22595);
/* harmony import */ var _context_menu_context_menu_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../context-menu/context-menu.module */ 75672);
/* harmony import */ var _layout_layout_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../layout/layout.module */ 67126);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 18259);














const routes = [
    {
        path: '',
        component: _trashcan_component__WEBPACK_IMPORTED_MODULE_0__.TrashcanComponent,
        data: {
            title: 'APP.BROWSE.TRASHCAN.TITLE',
            sortingPreferenceKey: 'trashcan'
        }
    }
];
class AppTrashcanModule {
}
AppTrashcanModule.ɵfac = function AppTrashcanModule_Factory(t) { return new (t || AppTrashcanModule)(); };
AppTrashcanModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: AppTrashcanModule });
AppTrashcanModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
        _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule.forChild(),
        _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes),
        _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__.ContentModule.forChild(),
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_3__.DirectivesModule,
        _common_common_module__WEBPACK_IMPORTED_MODULE_1__.AppCommonModule,
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_2__.AppToolbarModule,
        _context_menu_context_menu_module__WEBPACK_IMPORTED_MODULE_4__.ContextMenuModule,
        _layout_layout_module__WEBPACK_IMPORTED_MODULE_5__.AppLayoutModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](AppTrashcanModule, { declarations: [_trashcan_component__WEBPACK_IMPORTED_MODULE_0__.TrashcanComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule, _alfresco_adf_content_services__WEBPACK_IMPORTED_MODULE_10__.ContentModule, _directives_directives_module__WEBPACK_IMPORTED_MODULE_3__.DirectivesModule,
        _common_common_module__WEBPACK_IMPORTED_MODULE_1__.AppCommonModule,
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_2__.AppToolbarModule,
        _context_menu_context_menu_module__WEBPACK_IMPORTED_MODULE_4__.ContextMenuModule,
        _layout_layout_module__WEBPACK_IMPORTED_MODULE_5__.AppLayoutModule], exports: [_trashcan_component__WEBPACK_IMPORTED_MODULE_0__.TrashcanComponent] }); })();


/***/ })

}]);
//# sourceMappingURL=apps_content-ce_app_src_app_components_trashcan_trashcan_module_ts.js.map