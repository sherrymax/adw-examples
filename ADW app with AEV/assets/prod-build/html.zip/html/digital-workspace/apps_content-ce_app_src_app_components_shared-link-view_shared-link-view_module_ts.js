"use strict";
(self["webpackChunkcontent_ee"] = self["webpackChunkcontent_ee"] || []).push([["apps_content-ce_app_src_app_components_shared-link-view_shared-link-view_module_ts"],{

/***/ 41702:
/*!***********************************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/shared-link-view/shared-link-view.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedLinkViewComponent": () => (/* binding */ SharedLinkViewComponent)
/* harmony export */ });
/* harmony import */ var _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @alfresco/aca-shared/store */ 99311);
/* harmony import */ var _alfresco_js_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @alfresco/js-api */ 27015);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 79441);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 42720);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 34361);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 81134);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 85816);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 18293);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 22663);
/* harmony import */ var _alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @alfresco/aca-shared */ 27125);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 18259);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngrx/store */ 9876);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../projects/aca-shared/src/lib/components/tool-bar/toolbar-action/toolbar-action.component */ 82121);
/*!
 * @license
 * Alfresco Example Content Application
 *
 * Copyright (C) 2005 - 2020 Alfresco Software Limited
 *
 * This file is part of the Alfresco Example Content Application.
 * If the software was purchased under a paid Alfresco license, the terms of
 * the paid license agreement will prevail.  Otherwise, the software is
 * provided under the following open source license terms:
 *
 * The Alfresco Example Content Application is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The Alfresco Example Content Application is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */















function SharedLinkViewComponent_ng_container_0_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "aca-toolbar-action", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const action_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("actionRef", action_r2);
} }
function SharedLinkViewComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "adf-viewer", 1)(2, "adf-viewer-toolbar-actions");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, SharedLinkViewComponent_ng_container_0_ng_container_3_Template, 2, 1, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("allowPrint", false)("allowDownload", false)("allowFullScreen", false)("sharedLinkId", ctx_r0.sharedLinkId)("allowGoBack", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r0.viewerToolbarActions)("ngForTrackBy", ctx_r0.trackByActionId);
} }
class SharedLinkViewComponent {
    constructor(route, store, extensions, alfrescoApiService) {
        this.route = route;
        this.store = store;
        this.extensions = extensions;
        this.alfrescoApiService = alfrescoApiService;
        this.onDestroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
        this.sharedLinkId = null;
        this.viewerToolbarActions = [];
        this.sharedLinksApi = new _alfresco_js_api__WEBPACK_IMPORTED_MODULE_5__.SharedlinksApi(this.alfrescoApiService.getInstance());
    }
    ngOnInit() {
        this.route.params
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.mergeMap)((params) => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.forkJoin)([(0,rxjs__WEBPACK_IMPORTED_MODULE_8__.from)(this.sharedLinksApi.getSharedLink(params.id)), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)(params.id)]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.of)([null, params.id])))))
            .subscribe(([sharedEntry, sharedId]) => {
            if (sharedEntry) {
                this.store.dispatch(new _alfresco_aca_shared_store__WEBPACK_IMPORTED_MODULE_0__.SetSelectedNodesAction([sharedEntry]));
            }
            this.sharedLinkId = sharedId;
        });
        this.extensions
            .getSharedLinkViewerToolbarActions()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.takeUntil)(this.onDestroy$))
            .subscribe((actions) => {
            this.viewerToolbarActions = actions;
        });
    }
    ngOnDestroy() {
        this.onDestroy$.next(true);
        this.onDestroy$.complete();
    }
    trackByActionId(_, action) {
        return action.id;
    }
}
SharedLinkViewComponent.ɵfac = function SharedLinkViewComponent_Factory(t) { return new (t || SharedLinkViewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_13__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_alfresco_aca_shared__WEBPACK_IMPORTED_MODULE_1__.AppExtensionService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.AlfrescoApiService)); };
SharedLinkViewComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: SharedLinkViewComponent, selectors: [["app-shared-link-view"]], hostAttrs: [1, "app-shared-link-view"], decls: 1, vars: 1, consts: [[4, "ngIf"], [3, "allowPrint", "allowDownload", "allowFullScreen", "sharedLinkId", "allowGoBack"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "actionRef"]], template: function SharedLinkViewComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, SharedLinkViewComponent_ng_container_0_Template, 4, 7, "ng-container", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.sharedLinkId);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerComponent, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_14__.ViewerToolbarActionsComponent, _projects_aca_shared_src_lib_components_tool_bar_toolbar_action_toolbar_action_component__WEBPACK_IMPORTED_MODULE_2__.ToolbarActionComponent], styles: [".app-shared-link-view {\n  width: 100%;\n  height: 100%;\n}\n.app-shared-link-view .adf-viewer-toolbar .adf-toolbar-divider {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNoYXJlZC1saW5rLXZpZXcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQUNGO0FBQ0U7RUFDRSxhQUFBO0FBQ0oiLCJmaWxlIjoic2hhcmVkLWxpbmstdmlldy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hcHAtc2hhcmVkLWxpbmstdmlldyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG5cbiAgLmFkZi12aWV3ZXItdG9vbGJhciAuYWRmLXRvb2xiYXItZGl2aWRlciB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxufVxuIl19 */"], encapsulation: 2 });


/***/ }),

/***/ 65895:
/*!********************************************************************************************!*\
  !*** ./apps/content-ce/app/src/app/components/shared-link-view/shared-link-view.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppSharedLinkViewModule": () => (/* binding */ AppSharedLinkViewModule)
/* harmony export */ });
/* harmony import */ var _shared_link_view_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shared-link-view.component */ 41702);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 48750);
/* harmony import */ var _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @alfresco/adf-core */ 53967);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 73903);
/* harmony import */ var _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../directives/directives.module */ 22595);
/* harmony import */ var _common_common_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../common/common.module */ 81054);
/* harmony import */ var _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolbar/toolbar.module */ 72390);
/* harmony import */ var _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../info-drawer/info.drawer.module */ 53617);
/* harmony import */ var _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../extensions/core.extensions.module */ 30416);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 18259);













const routes = [
    {
        path: '',
        component: _shared_link_view_component__WEBPACK_IMPORTED_MODULE_0__.SharedLinkViewComponent,
        data: {
            title: 'APP.PREVIEW.TITLE'
        }
    }
];
class AppSharedLinkViewModule {
}
AppSharedLinkViewModule.ɵfac = function AppSharedLinkViewModule_Factory(t) { return new (t || AppSharedLinkViewModule)(); };
AppSharedLinkViewModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: AppSharedLinkViewModule });
AppSharedLinkViewModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
        _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule.forChild(),
        _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule.forChild(routes),
        _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__.DirectivesModule,
        _common_common_module__WEBPACK_IMPORTED_MODULE_2__.AppCommonModule,
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__.AppToolbarModule,
        _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_5__.CoreExtensionsModule.forChild(),
        _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_4__.AppInfoDrawerModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](AppSharedLinkViewModule, { declarations: [_shared_link_view_component__WEBPACK_IMPORTED_MODULE_0__.SharedLinkViewComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _alfresco_adf_core__WEBPACK_IMPORTED_MODULE_8__.CoreModule, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterModule, _directives_directives_module__WEBPACK_IMPORTED_MODULE_1__.DirectivesModule,
        _common_common_module__WEBPACK_IMPORTED_MODULE_2__.AppCommonModule,
        _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_3__.AppToolbarModule, _extensions_core_extensions_module__WEBPACK_IMPORTED_MODULE_5__.CoreExtensionsModule, _info_drawer_info_drawer_module__WEBPACK_IMPORTED_MODULE_4__.AppInfoDrawerModule], exports: [_shared_link_view_component__WEBPACK_IMPORTED_MODULE_0__.SharedLinkViewComponent] }); })();


/***/ })

}]);
//# sourceMappingURL=apps_content-ce_app_src_app_components_shared-link-view_shared-link-view_module_ts.js.map